package com.hms.login;

public class PatientLogin extends UserLogin {
}
