package com.hms.login;

public class DoctorLogin extends UserLogin {

}
