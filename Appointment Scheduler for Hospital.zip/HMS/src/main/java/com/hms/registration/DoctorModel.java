package com.hms.registration;

import com.hms.registration.UserModel;
import jakarta.persistence.*;

@Entity
@Table(name = "doctor")
public class DoctorModel extends UserModel {

}
