package com.hms.registration;

import com.hms.registration.UserModel;
import jakarta.persistence.*;

@Entity
@Table(name = "patient")
public class PatientModel extends UserModel {

}
